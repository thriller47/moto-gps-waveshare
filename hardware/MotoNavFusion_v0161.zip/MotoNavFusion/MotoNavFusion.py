"""MotoNav v0.16.1 - generatore per Autodesk Fusion 360 (Python API).

Culla fissa M10 con sede posteriore RACCORDATA e ghiera frontale a baionetta.
v0.16.1: finestra USB pulita a ore 6 nella culla e nella parete della ghiera.
Angoli dei tre denti spostati insieme di 30 gradi per liberare il passaggio USB.
Pin piu profondo, due tasche per i pulsanti e maggiore sostegno sotto le guide.
Sezioni dei denti, tasca di chiusura e O-ring invariati; varia la fase angolare dell aggancio.
I tagli restano ISOLATI tramite participantBodies.
L'accesso frontale resta Ø55.6 mm: niente sottosquadra che intrappoli il Waveshare.
Quote in mm; API Fusion usa cm internamente. Crea un NUOVO documento.

Modello d'assieme in posizione di baionetta CHIUSA: per esportare gli STL
separare i componenti e appoggiarli singolarmente sul piano di stampa.
Per modificare il modello, cambiare CONFIG e rieseguire lo script.
I parametri creati nella finestra Parametri sono riferimenti di progetto;
non tutte le feature sono guidate da espressioni di parametri Fusion.
"""
import adsk.core
import adsk.fusion
import traceback
import math

# ---- PARAMETRI PER LE VARIANTI (mm, salvo angoli indicati in gradi) ----
CONFIG = {
    'culla_diametro': 67.0,
    'fondo_spessore': 9.0,
    'esp_diametro_max': 55.0,
    'esp_spessore': 15.05,
    'gioco_diametrale': 0.60,          # +0.6 SUL DIAMETRO: 0.3 mm per lato
    'diametro_bordo_posteriore': 48.96, # RIFERIMENTO, profilo originale da confrontare
    'raggio_raccordo_posteriore': 3.02, # (55-48.96)/2: raccordo tangente indicativo
    'inserto_diametro': 30.0,          # v0.8: ridotto da 35 a 30 mm
    'inserto_altezza': 6.0,
    'inserto_gioco_diametrale': 0.20,
    'foro_bullone_diametro': 10.50,    # solo foro di passaggio; svasatura in officina
    'rondella_diametro': 30.0,
    'rondella_altezza': 2.0,
    'cordolo_diametro': 1.75,
    'gola_larghezza': 1.90,           # gola posteriore
    'gola_front_larghezza': 1.60,     # v0.14.1: larghezza invariata, lip interno portato a 1.00 mm
    'gola_profondita': 1.10,
    'compressione_per_anello': 0.30,
    'gola_post_diametro_medio': 44.0,
    'gola_front_diametro_medio': 48.00, # v0.14.1: lip 1.00 mm, bordo esterno su zona raccordata Ø49.60
    'ghiera_apertura_diametro': 44.4,  # > area attiva Ø43.76; 0.32 mm radiali nominali
    'ghiera_spessore': 3.0,
    'denti_numero': 3,
    'dente_angolo': 13.0,          # invariato rispetto a v0.9
    'dente_raggio_interno': 30.70, # v0.12: radice inglobata per 2.8 mm nel corpo della culla
    'dente_raggio_esterno': 36.95,  # v0.11: dente piu profondo verso l esterno # v0.10: +0.85 mm di presa RADIALE rispetto a v0.9
    'dente_altezza': 2.60,        # v0.12: sezione strutturale ASSIALE piena del dente
    'dente_z_sotto_bordo': 3.45,   # quota in mm dal bordo aperto della culla fino alla base del dente
    'tasca_chiusa_mezzo_angolo': 9.5, # almeno 3 deg oltre ciascun lato dente
    'rampa_angolo_inizio': 27.5,  # vicino alla finestra di inserimento
    'ingresso_mezzo_angolo': 9.0,  # v0.14: imbocco 18° invece di 15°, non tocca tasca finale
    'gonna_raggio_esterno': 39.25,  # Ø78.5; preserva 1.90 mm di parete
    'gonna_raggio_interno': 33.85,
    'canale_raggio_esterno': 37.35,  # 0.40 mm di gioco nominale rispetto al dente # v0.11: canale coerente con la nuova presa # v0.10: gioco radiale 0.45 mm sul dente maggiorato
    'rampa_gradini': 12,            # v0.14: passo meno evidente, tasca finale invariata
    'gioco_assiale_guida_finale': 0.25, # luce inferiore e superiore della tasca finale
    'raccordo_bordo_ghiera': 0.70,  # solo spigolo esterno frontale
    'raccordo_fondo_culla': 0.70,   # solo spigolo esterno posteriore
    'svaso_guida_pin_D': 3.2,       # imbocco cilindrico per coppiglia, NON svasatura M10
    'svaso_guida_pin_P': 0.60,
    'rotazione_chiusura': 35.0,        # ghiera ruota +35° per chiudere
    'blocco_angolo_chiuso': 60.0,
    'blocco_raggio': 31.0,
    'blocco_foro_diametro': 2.40,
    'blocco_sede_profondita': 9.00,    # v0.15: profondita reale della sede PIN nella culla
    'perno_diametro_guida': 2.0,
    'perno_sporgenza_guida': 2.5,
    'vecchio_distacco_coperchio': 2.0, # solo riferimento prototipo precedente
    # Piccola tasca non passante per l'inizio del laccetto.
    # La fessura dedicata si aggiunge sotto, in un settore fra denti.
    'laccetto_tasca_attiva': True,
    'laccetto_angolo': 300.0,        # fra i denti (240/360), lontano dal fermo (60)
    'laccetto_apertura_gradi': 20.0,
    'laccetto_raggio_interno': 27.20, # attraversa la parete fino alla cavita Ø55.6
    'laccetto_raggio_esterno': 30.65, # lascia ~2.85 mm di parete fino a Ø67
    'laccetto_tasca_profondita': 7.0,
    # Intaglio sulla SOLA CULLA, aperto radialmente verso l'esterno.
    # Profondita ASSIALE: 7 mm dal bordo superiore, larghezza 1.5 mm.
    # Nessuna finestra di passaggio nella ghiera, come richiesto.
    'laccetto_intaglio_attivo': True,
    'laccetto_intaglio_profondita': 7.0,
    'laccetto_intaglio_larghezza': 1.50,
    'laccetto_intaglio_inizio_r': 30.35,  # sovrappone la tasca esistente (fino a r30.65)
    'laccetto_intaglio_fine_r': 34.10,    # oltre il bordo culla r33.5
    # v0.15 - scarichi locali per i due pulsanti laterali.
    # Immaginare il LACCETTO alle ore 12 guardando il display frontalmente.
    # Gli offset seguenti sono ORARI rispetto al laccetto (provvisori da foto):
    # 60 deg = ore 2 (POWER), 120 deg = ore 4 (RESET).
    'pulsanti_tasche_attive': True,
    'pulsante_power_offset_orario': 60.0,
    'pulsante_reset_offset_orario': 120.0,
    'pulsante_tasca_profondita_radiale': 1.00,  # al massimo 1 mm oltre la parete interna
    'pulsante_tasca_angolo_totale': 14.0,       # circa 6.8 mm tangenziali a r28
    'pulsante_tasca_altezza_assiale': 13.0,     # dal bordo superiore verso il fondo
    'pulsante_tasca_sovrapposizione': 0.40,     # entra nella cavita per garantire il taglio
    # v0.15 - rinforzo delle guide SOTTO la tasca di fermo,
    # allungando assialmente la gonna verso il fondo, SENZA toccare le guide:
    'gonna_sotto_guide_extra': 1.50,           # 1.50 -> 3.00 mm di sostegno nominale
    # v0.16 - nuova uscita USB, ORE 6 rispetto al laccetto (ore 12).
    # Vista frontale: angolo CAD = laccetto_angolo + 180 deg.
    # L'apertura della GHIERA interessa SOLTANTO la gonna laterale: la corona
    # anteriore e la gola dell'O-ring rimangono continue.
    'usb_uscita_attiva': True,
    'usb_offset_orario': 180.0,
    'usb_larghezza': 12.0,              # tangenziale in mm; MISURARE il connettore reale
    'usb_margine_laterale': 1.0,       # mm per lato: luce passante 14 mm nella culla e ghiera
    'usb_culla_profondita': 12.0,        # assiale, dal bordo della culla; prova iniziale
    'usb_raggio_inizio_culla': 27.10,    # entra leggermente nella cavita Ø55.6
    'usb_raggio_fine_culla': 34.50,      # oltre la culla Ø67
    'usb_raggio_inizio_ghiera': 33.55,   # dentro il mantello della ghiera
    'usb_raggio_fine_ghiera': 40.20,    # oltre il raggio esterno 39.25
    'baionetta_offset_angolare': 30.0,  # ruota TUTTI i denti e le relative guide



}


def mmin(value):
    return adsk.core.ValueInput.createByString('{:.8f} mm'.format(float(value)))


def pxy(x, y):
    return adsk.core.Point3D.create(x / 10.0, y / 10.0, 0)


def circle(sk, radius):
    sk.sketchCurves.sketchCircles.addByCenterRadius(pxy(0, 0), radius / 10.0)


def plane_sketch(comp, z, label):
    if abs(z) < 1e-8:
        plane = comp.xYConstructionPlane
    else:
        settings = comp.constructionPlanes.createInput()
        settings.setByOffset(comp.xYConstructionPlane, mmin(z))
        plane = comp.constructionPlanes.add(settings)
        plane.name = 'Piano - ' + label
    sk = comp.sketches.add(plane)
    sk.name = label
    return sk


def disk_sketch(comp, z, label, radii):
    sk = plane_sketch(comp, z, label)
    for radius in radii:
        circle(sk, radius)
    return sk


def extrude(comp, sketch, distance, operation, label, annulus=False):
    expected_loops = 2 if annulus else 1
    matches = [sketch.profiles.item(i) for i in range(sketch.profiles.count)
               if sketch.profiles.item(i).profileLoops.count == expected_loops]
    if not matches:
        raise RuntimeError('Profilo non disponibile per ' + label)
    prof = max(matches, key=lambda p: p.areaProperties().area)
    features = comp.features.extrudeFeatures
    x = features.createInput(prof, operation)
    x.setDistanceExtent(False, mmin(distance))
    # CRITICO v0.13.1: Fusion, senza participantBodies, taglia tutti i corpi
    # intersecati, anche quelli di ALTRI componenti visibili.
    # Cosi le rampe della GHIERA erodevano i DENTI della CULLA: ~0.198 mm.
    if operation == adsk.fusion.FeatureOperations.CutFeatureOperation:
        owned_solids = [comp.bRepBodies.item(k)
                        for k in range(comp.bRepBodies.count)
                        if comp.bRepBodies.item(k).isSolid]
        if len(owned_solids) != 1:
            raise RuntimeError('%s: taglio non applicato: atteso un solo solido in %s, trovati %d' %
                               (label, comp.name, len(owned_solids)))
        x.participantBodies = owned_solids
    feature = features.add(x)
    feature.name = label
    return feature


def sector_sketch(comp, z, label, r0, r1, a0, a1):
    sk = plane_sketch(comp, z, label)
    n = max(4, int(math.ceil(abs(a1 - a0) / 2.0)))
    theta = [math.radians(a0+(a1-a0)*i/n) for i in range(n+1)]
    points = [(r1*math.cos(a), r1*math.sin(a)) for a in theta]
    points += [(r0*math.cos(a), r0*math.sin(a)) for a in reversed(theta)]
    lines = sk.sketchCurves.sketchLines
    for i in range(len(points)):
        lines.addByTwoPoints(pxy(*points[i]), pxy(*points[(i+1) % len(points)]))
    return sk


def sector_cut_or_join(comp, z, label, r0, r1, a0, a1, height, op):
    sk = sector_sketch(comp, z, label+' schizzo', r0, r1, a0, a1)
    return extrude(comp, sk, height, op, label)



def radial_slot_sketch(comp, z, label, r0, r1, angle_deg, width):
    """Rettangolo in pianta, largo width tangenziale e lungo (r1-r0) radialmente.

    Il taglio rettilineo rimane largo 1.50 mm anche sul diametro esterno.
    Si sovrappone alla tasca interna e sbuca oltre la parete della culla.
    """
    if r1 <= r0 or width <= 0:
        raise ValueError('Intaglio laccetto: raggi/larghezza non validi')
    a = math.radians(angle_deg)
    ux, uy = math.cos(a), math.sin(a)
    tx, ty = -uy, ux
    half = width / 2.0
    corners = [
        (r0*ux-half*tx, r0*uy-half*ty),
        (r1*ux-half*tx, r1*uy-half*ty),
        (r1*ux+half*tx, r1*uy+half*ty),
        (r0*ux+half*tx, r0*uy+half*ty),
    ]
    sk = plane_sketch(comp, z, label)
    lines = sk.sketchCurves.sketchLines
    for i in range(4):
        lines.addByTwoPoints(pxy(*corners[i]), pxy(*corners[(i+1)%4]))
    return sk


def notch_cut(comp, z, label, r0, r1, angle, width, height):
    sk = radial_slot_sketch(comp, z, label + ' schizzo', r0, r1, angle, width)
    return extrude(comp, sk, height,
                   adsk.fusion.FeatureOperations.CutFeatureOperation, label)



def fillet_outer_circular_edge(comp, radius_mm, z_mm, fillet_mm, name):
    """Apply only to a known *external* complete circular edge.

    Returns (success, info) and keeps the model intact if not found.
    It avoids any rounding of the narrow TPU seats and bayonet teeth.
    """
    if fillet_mm <= 0:
        return True, 'disattivato'
    wanted_r = radius_mm / 10.0
    wanted_z = z_mm / 10.0
    edges = adsk.core.ObjectCollection.create()
    for body in comp.bRepBodies:
        for edge in body.edges:
            curve = adsk.core.Circle3D.cast(edge.geometry)
            if curve is None:
                continue
            center = curve.center
            if (abs(curve.radius - wanted_r) < 0.003 and
                abs(center.z - wanted_z) < 0.003 and
                abs(center.x) < 0.003 and abs(center.y) < 0.003):
                edges.add(edge)
    if edges.count != 1:
        return False, '%s: trovati %d bordi, previsto 1' % (name, edges.count)
    try:
        fillets = comp.features.filletFeatures
        inp = fillets.createInput()
        inp.isRollingBallCorner = True
        inp.edgeSetInputs.addConstantRadiusEdgeSet(edges, mmin(fillet_mm), True)
        f = fillets.add(inp)
        f.name = name
        return True, name + ': R%.2f mm applicato' % fillet_mm
    except Exception as e:
        return False, name + ': raccordo non eseguito (%s)' % str(e)


def get_unique_solid(comp, context):
    """Get the only solid in an owning component (not a visual proxy)."""
    solids = [comp.bRepBodies.item(j) for j in range(comp.bRepBodies.count)
              if comp.bRepBodies.item(j).isSolid]
    if len(solids) != 1:
        raise RuntimeError('%s: atteso UN corpo solido, trovati %d' %
                           (context,len(solids)))
    return solids[0]


def solid_at(body, radius_mm, angle_deg, z_mm):
    """Uses native Fusion BRep; all values here are in millimeters."""
    t=math.radians(angle_deg)
    point=adsk.core.Point3D.create(radius_mm*math.cos(t)/10.0,
                                   radius_mm*math.sin(t)/10.0, z_mm/10.0)
    status=body.pointContainment(point)
    if status == adsk.fusion.PointContainment.UnknownPointContainment:
        raise RuntimeError('pointContainment indeciso: r=%.2f a=%.1f z=%.2f' %
                           (radius_mm,angle_deg,z_mm))
    return status in (adsk.fusion.PointContainment.PointInsidePointContainment,
                      adsk.fusion.PointContainment.PointOnPointContainment)


def solid_at_usb_offset(body, radius_mm, angle_deg, tangent_mm, z_mm):
    """Probe a tangential distance from the centerline of the rectangular USB slot.

    radius_mm is distance along slot axis, tangent_mm is the signed offset
    measured in the XY plane. This tests the actual rectangular clearance.
    """
    a = math.radians(angle_deg)
    x = radius_mm*math.cos(a) - tangent_mm*math.sin(a)
    y = radius_mm*math.sin(a) + tangent_mm*math.cos(a)
    point = adsk.core.Point3D.create(x/10.0, y/10.0, z_mm/10.0)
    status = body.pointContainment(point)
    if status == adsk.fusion.PointContainment.UnknownPointContainment:
        raise RuntimeError('USB: pointContainment sconosciuto al punto t=%.2f z=%.2f' %
                           (tangent_mm,z_mm))
    return status in (adsk.fusion.PointContainment.PointInsidePointContainment,
                      adsk.fusion.PointContainment.PointOnPointContainment)


def radial_reach(body, angle_deg, z_mm, base_radius, max_radius, dr=0.05):
    """Measure radial projection beyond the cup at the CENTRE of each lug."""
    last=None
    n=int(math.ceil((max_radius-base_radius)/dr))
    for k in range(n+1):
        r=base_radius+(max_radius-base_radius)*k/max(1,n)
        if solid_at(body,r,angle_deg,z_mm):
            last=r
    return max(0.0,(last-base_radius) if last is not None else 0.0)


def check_actual_teeth(cup, bezel, C, mid_z, bottom_z, top_z):
    """Post-build BRep verification. Reject 0.195mm tooth, not just CONFIG errors."""
    cup_body=get_unique_solid(cup,'Culla dopo unione denti')
    bezel_body=get_unique_solid(bezel,'Ghiera dopo fresatura canali')
    radius=C['culla_diametro']/2.0
    end=C['dente_raggio_esterno']
    zclear=C['gioco_assiale_guida_finale']
    reports=[]
    for i in range(C['denti_numero']):
        ang=(C['baionetta_offset_angolare']+360.0*i/C['denti_numero']) % 360.0
        reach=radial_reach(cup_body,ang,mid_z,radius,end+0.02)
        # Three specific points in the tooth and within a pocket, away from edges.
        test_r=radius+1.5
        cup_full=solid_at(cup_body,test_r,ang,mid_z)
        pocket_clear=not solid_at(bezel_body,test_r,ang,mid_z)
        # The rear and frontal portions of the bezel must stop the tooth moving axially.
        front_lip=solid_at(bezel_body,test_r,ang,top_z+zclear+0.30)
        back_lip=solid_at(bezel_body,test_r,ang,bottom_z-zclear-0.35)
        reports.append((i+1,reach,cup_full,pocket_clear,front_lip,back_lip))
        if reach<2.8 or not all((cup_full,pocket_clear,front_lip,back_lip)):
            raise RuntimeError(
                'Dente %d NON CONFORME nel CAD: sporgenza reale %.3f mm, '
                'culla=%s canale=%s battuta_sup=%s battuta_inf=%s. '
                'Il modello NON e pronto alla stampa.' %
                (i+1,reach,cup_full,pocket_clear,front_lip,back_lip))
    return reports


def explicit_join_lug(comp, z, label, r0, r1, a0, a1, height):
    """Make tooth separately, then perform Fusion's real Join boolean.

    This avoids relying on an implicit Join from an extrusion on the parent.
    The Combine result is checked to be ONE continuous B-Rep solid.
    """
    base=get_unique_solid(comp,label+' prima di unione')
    sk=sector_sketch(comp,z,label+' profilo pieno',r0,r1,a0,a1)
    temp=extrude(comp,sk,height,
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                label+' - solido di lavoro')
    if comp.bRepBodies.count != 2:
        raise RuntimeError(label+': la creazione del corpo separato non ha prodotto due solidi')
    tools=adsk.core.ObjectCollection.create()
    # Use the result body of THIS extrusion, never the incidental ordering of
    # comp.bRepBodies; entity wrappers can be recreated by the Fusion API.
    if temp.bodies.count != 1:
        raise RuntimeError(label+': estrusione separata non ha prodotto un corpo')
    tool_body=temp.bodies.item(0)
    if tool_body is None:
        raise RuntimeError(label+': corpo utensile non trovato')
    tools.add(tool_body)
    join=comp.features.combineFeatures
    inp=join.createInput(base, tools)
    inp.operation=adsk.fusion.FeatureOperations.JoinFeatureOperation
    inp.isNewComponent=False
    inp.isKeepToolBodies=False
    feature=join.add(inp)
    if not feature:
        raise RuntimeError(label+': Fusion non ha creato la feature Combine')
    feature.name=label+' - UNIONE BOOLEANA ESPRESSA'
    return get_unique_solid(comp,label+' dopo unione')


def create_part(root, name):
    occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
    occ.component.name = name
    return occ.component


def add_param(design, key, val, note, angular=False):
    units = 'deg' if angular else 'mm'
    design.userParameters.add(key,
        adsk.core.ValueInput.createByString('{:.7f} {}'.format(float(val), units)),
        units, note)


def rz(sketch, radius_mm, z_mm):
    """Convert point on model XZ plane to sketch-local coordinates."""
    model_p = adsk.core.Point3D.create(radius_mm/10.0, 0, z_mm/10.0)
    return sketch.modelToSketchSpace(model_p)


def arc(sk, begin, mid, end):
    return sk.sketchCurves.sketchArcs.addByThreePoints(rz(sk, *begin),
                                                     rz(sk, *mid),
                                                     rz(sk, *end))


def line(sk, a, b):
    return sk.sketchCurves.sketchLines.addByTwoPoints(rz(sk, *a), rz(sk, *b))


def revolved_profile(comp, name, bottom_z, top_z, r_back, r_max, do_upper, operation):
    """Use TRUE circular arcs in meridian section, then revolve about Z.

    CULLA: quarter-round at rear ONLY + straight full-diameter entry.
    REFERENCE ESP32: rear and front quarter-rounds; hidden in document.
    """
    if not (r_max > r_back > 0):
        raise ValueError('Raggi del profilo non validi')
    shoulder = r_max - r_back
    if (top_z - bottom_z) < (2.0 * shoulder + 0.2):
        raise ValueError('Altezza troppo piccola per i raccordi')
    sk = comp.sketches.add(comp.xZConstructionPlane)
    sk.name = name + ' - sezione XZ'
    base = (0.0, bottom_z)
    rim = (r_back, bottom_z)
    curve_top = (r_max, bottom_z + shoulder)
    line(sk, base, rim)
    arc(sk, rim,
        (r_back + shoulder/math.sqrt(2),
         bottom_z + shoulder*(1 - 1/math.sqrt(2))),
        curve_top)
    if do_upper:
        upper_start = (r_max, top_z - shoulder)
        upper_end = (r_back, top_z)
        line(sk, curve_top, upper_start)
        arc(sk, upper_start,
            (r_back + shoulder/math.sqrt(2),
             top_z - shoulder*(1 - 1/math.sqrt(2))),
            upper_end)
        line(sk, upper_end, (0, top_z))
    else:
        # IMPORTANT: the opening must remain >= 55.6 mm diameter.
        # A symmetric inside curve here would trap the 55 mm device.
        line(sk, curve_top, (r_max, top_z))
        line(sk, (r_max, top_z), (0, top_z))
    line(sk, (0, top_z), base)
    profiles = [sk.profiles.item(i) for i in range(sk.profiles.count)]
    if len(profiles) != 1:
        raise RuntimeError('Sezione raccordata non chiusa (%d profili)' % len(profiles))
    revs = comp.features.revolveFeatures
    inp = revs.createInput(profiles[0], comp.zConstructionAxis, operation)
    inp.setAngleExtent(False, adsk.core.ValueInput.createByReal(2.0 * math.pi))
    if operation == adsk.fusion.FeatureOperations.CutFeatureOperation:
        owned_solids = [comp.bRepBodies.item(k)
                        for k in range(comp.bRepBodies.count)
                        if comp.bRepBodies.item(k).isSolid]
        if len(owned_solids) != 1:
            raise RuntimeError(name + ': impossibile isolare il corpo da raccordare')
        inp.participantBodies = owned_solids
    f = revs.add(inp)
    f.name = name
    return f


def radial_hole_sketch(comp, z, label, radius, angle, diameter):
    sk = plane_sketch(comp, z, label)
    a = math.radians(angle)
    sk.sketchCurves.sketchCircles.addByCenterRadius(
        pxy(radius*math.cos(a), radius*math.sin(a)), diameter/20.0)
    return sk


def hide_part(root, component):
    for i in range(root.occurrences.count):
        occ = root.occurrences.item(i)
        if occ.component == component:
            occ.isLightBulbOn = False
            return


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
        design = adsk.fusion.Design.cast(app.activeProduct)
        design.designType = adsk.fusion.DesignTypes.ParametricDesignType
        root = design.rootComponent
        C = CONFIG

        D = C['culla_diametro']
        floor = C['fondo_spessore']
        esp_h = C['esp_spessore']
        cord = C['cordolo_diametro']
        gr_depth = C['gola_profondita']
        compress_each = C['compressione_per_anello']
        elastic_gap = cord - gr_depth - compress_each
        if not (0.20 < elastic_gap < 1.0):
            raise ValueError('Gioco assiale non plausibile: %.2f' % elastic_gap)
        top = floor + esp_h + 2*elastic_gap
        max_r = (C['esp_diametro_max'] + C['gioco_diametrale'])/2.0
        rear_r = (C['diametro_bordo_posteriore'] + C['gioco_diametrale'])/2.0
        shoulder = max_r-rear_r
        if abs(shoulder-C['raggio_raccordo_posteriore']) > 0.001:
            raise ValueError('Raccordo deve essere max_r - rear_r = %.3f' % shoulder)
        ins_d = C['inserto_diametro']
        ins_h = C['inserto_altezza']
        bolt = C['foro_bullone_diametro']
        skirt_bot = top-5.2-C['gonna_sotto_guide_extra']
        lug_bot = top-C['dente_z_sotto_bordo']
        lug_h = C['dente_altezza']
        twist = C['rotazione_chiusura']
        lock_a = C['blocco_angolo_chiuso']
        lock_rad = C['blocco_raggio']
        lock_d = C['blocco_foro_diametro']
        # The bezel is GENERATED IN CLOSED POSITION. To open, rotate -35°.
        # La ghiera NON presenta la finestra del laccetto; ha SOLO quella USB a ore 6.
        closed_angle_offset = twist

        if C['laccetto_raggio_esterno'] > (D/2 - 2.5):
            raise ValueError('La tasca del laccetto lascia parete insufficiente')
        front_width = C['gola_front_larghezza']
        front_in_r = (C['gola_front_diametro_medio'] - front_width)/2.0
        front_out_r = (C['gola_front_diametro_medio'] + front_width)/2.0
        front_lip_width = front_in_r - C['ghiera_apertura_diametro']/2.0
        if front_lip_width < 0.995:
            raise ValueError('Labbro interno ghiera inferiore a 1.00 mm (nominale): %.3f mm' % front_lip_width)
        # Ø48.96 e un riferimento nominale del bordo, NON una misura della zona piana reale.
        # Con lip 1 mm e gola larga 1.6 mm, la gola si estende a Ø49.6:
        # occorre verificare la superficie di appoggio sul guscio metallico.
        front_outer_overhang = max(0.0, front_out_r-C['diametro_bordo_posteriore']/2.0)
        if front_outer_overhang > 0.35+1e-6:
            raise ValueError('Gola troppo esterna rispetto al riferimento Waveshare: %.3f mm' % front_outer_overhang)
        if C['ghiera_apertura_diametro'] <= 43.76:
            raise ValueError('Apertura ghiera inferiore all area frontale nominale')
        # v0.15: check extra reliefs are shallow, local and outside structural anchors.
        button_angles = []
        button_depth = C['pulsante_tasca_profondita_radiale']
        if C['pulsanti_tasche_attive']:
            if not (0.10 <= button_depth <= 1.0):
                raise ValueError('Profondita RADIALE tasche pulsanti fuori limite 0.1-1.0 mm')
            btn_a = C['pulsante_tasca_angolo_totale']
            if not (8.0 <= btn_a <= 20.0):
                raise ValueError('Ampiezza angolare tasche pulsanti fuori limite')
            btn_h = C['pulsante_tasca_altezza_assiale']
            if not (3.0 <= btn_h <= top-floor-0.5):
                raise ValueError('Altezza assiale tasche pulsanti fuori limite')
            if (max_r + button_depth) > C['dente_raggio_interno']-0.80:
                raise ValueError('Le tasche pulsanti si avvicinano troppo alla radice dei denti')
            for key in ('pulsante_power_offset_orario','pulsante_reset_offset_orario'):
                # L'angolo del laccetto e' il riferimento ore 12.
                # Angoli CAD positivi = antiorari; ore in senso orario = sottrazione.
                a = (C['laccetto_angolo'] - C[key]) % 360.0
                button_angles.append(a)
                dist_lanyard = abs((a-C['laccetto_angolo']+180)%360-180)
                if dist_lanyard < btn_a/2 + C['laccetto_apertura_gradi']/2 + 4.0:
                    raise ValueError('Tasca pulsante interferisce angolarmente col laccetto')
                dist_lock = abs((a-lock_a+180)%360-180)
                if dist_lock < btn_a/2 + 4.0:
                    raise ValueError('Tasca pulsante troppo vicina al fermo antisgancio')
            if abs((button_angles[0]-button_angles[1]+180)%360-180) < btn_a + 5.0:
                raise ValueError('Le due tasche pulsanti si sovrappongono')
        if C['laccetto_intaglio_attivo']:
            if not C['laccetto_tasca_attiva']:
                raise ValueError('La fessura laccetto richiede la tasca interna')
            if C['laccetto_intaglio_inizio_r'] >= C['laccetto_raggio_esterno'] - 0.10:
                raise ValueError('Intaglio laccetto NON sovrapposto alla tasca')
            if C['laccetto_intaglio_fine_r'] <= D/2 + 0.20:
                raise ValueError('Intaglio laccetto NON aperto verso esterno culla')
            if C['laccetto_intaglio_profondita'] >= top - floor - 0.5:
                raise ValueError('Intaglio laccetto troppo profondo rispetto al fondo')
            if C['laccetto_intaglio_larghezza'] <= 0:
                raise ValueError('Larghezza fessura non valida')
            # Controllo conservativo in posizione CHIUSA: denti e foro antisgancio.
            ang = C['laccetto_angolo'] % 360.0
            for i in range(C['denti_numero']):
                lug_angle = (C['baionetta_offset_angolare']+360.0*i/C['denti_numero']) % 360.0
                distance_deg = abs((ang-lug_angle+180.0)%360.0 - 180.0)
                if distance_deg < C['dente_angolo']/2.0 + 9.0:
                    raise ValueError('Intaglio laccetto troppo vicino a un dente')
            if abs((ang-lock_a+180.0)%360.0 - 180.0) < 12.0:
                raise ValueError('Intaglio laccetto troppo vicino al blocco')


        # v0.16: controllo geometrico conservativo del nuovo passaggio USB.
        usb_angle = (C['laccetto_angolo']-C['usb_offset_orario']) % 360.0
        usb_width = C['usb_larghezza'] + 2.0*C['usb_margine_laterale']
        if not (0.0 <= C['usb_margine_laterale'] <= 1.0):
            raise ValueError('USB: margine laterale consentito 0-1 mm per lato')
        usb_depth = C['usb_culla_profondita']
        if C['usb_uscita_attiva']:
            if not (8.0 <= usb_width <= 14.0):
                raise ValueError('USB: larghezza fuori intervallo iniziale 8-14 mm')
            if not (7.0 <= usb_depth <= min(14.0,top-floor-2.5)):
                raise ValueError('USB: profondita troppo corta o indebolisce il fondo')
            if C['usb_raggio_inizio_culla'] > max_r-0.3 or C['usb_raggio_fine_culla'] < D/2+0.6:
                raise ValueError('USB: lo scasso culla non attraversa tutta la parete')
            if (C['usb_raggio_inizio_ghiera'] > C['gonna_raggio_interno']-0.1 or
                    C['usb_raggio_fine_ghiera'] < C['gonna_raggio_esterno']+0.2):
                raise ValueError('USB: lo scasso ghiera non attraversa tutta la gonna')
            # La finestra attraversa l'intera gonna, ma NON la corona frontale.
            # Rispetta la zona di corsa della baionetta in posizione chiusa.
            half_angle=math.degrees(math.atan2(usb_width/2.0, max_r))
            def adist(x,y):
                return abs(((x-y+180.0)%360.0)-180.0)
            for i in range(C['denti_numero']):
                a=(C['baionetta_offset_angolare'] + i*360.0/C['denti_numero']) % 360.0
                # Canali e denti occupano da a-pocket_half a a+twist+entry_half.
                # Campioniamo l'arco di percorrenza a intervalli di 0.5 gradi.
                guide_begin=a-C['tasca_chiusa_mezzo_angolo']
                guide_end=a+twist+C['ingresso_mezzo_angolo']
                samples=int(math.ceil((guide_end-guide_begin)*2))
                gap=min(adist(usb_angle,guide_begin+j*(guide_end-guide_begin)/samples)
                        for j in range(samples+1))
                if gap < half_angle+4.0:
                    raise ValueError('USB troppo vicina al dente/guida %d (%.1f gradi)'%(i+1,gap))
            if adist(usb_angle,lock_a) < half_angle+8.0:
                raise ValueError('USB troppo vicina al PIN antisgancio')
            if adist(usb_angle,C['laccetto_angolo']) < half_angle+12.0:
                raise ValueError('USB troppo vicina al laccetto')

        # v0.13 - controlli radiali E assiali; dente come settore pieno
        # r30.70..36.95, h=2.60, inserito nella parete fino a r33.50.
        # Una tasca di bloccaggio continua lo accoglie per intero.
        radial_clearance = C['canale_raggio_esterno'] - C['dente_raggio_esterno']
        radial_under_skirt = C['dente_raggio_esterno'] - C['gonna_raggio_interno']
        tooth_projection = C['dente_raggio_esterno'] - D/2.0
        retaining_wall = C['gonna_raggio_esterno'] - C['canale_raggio_esterno']
        if not (0.35 - 1e-6 <= radial_clearance <= 0.60 + 1e-6):
            raise ValueError('Gioco RADIALE dente-canale fuori tolleranza: %.3f mm' % radial_clearance)
        if radial_under_skirt < 2.0:
            raise ValueError('Il dente non entra a sufficienza sotto la ghiera')
        if not (2.0 <= tooth_projection <= 3.8):
            raise ValueError('Sporgenza radiale del dente fuori campo: %.3f mm' % tooth_projection)
        if retaining_wall < 1.70:
            raise ValueError('Bordo esterno ghiera insufficiente: %.3f mm' % retaining_wall)
        root_embed = D / 2.0 - C['dente_raggio_interno']
        if root_embed < 2.5:
            raise ValueError('Radice dente insufficiente: %.2f mm (min 2.50)' % root_embed)
        if lug_h < 2.5:
            raise ValueError('Spessore ASSIALE del dente insufficiente: %.2f mm' % lug_h)
        if C['tasca_chiusa_mezzo_angolo'] < C['dente_angolo']/2.0 + 2.0:
            raise ValueError('Tasca bloccata non copre l intero dente e relativi giochi angolari')
        if (C['rampa_angolo_inizio'] <= C['tasca_chiusa_mezzo_angolo'] + 5.0):
            raise ValueError('Tratto di raccordo rampa troppo corto')
        # La tasca deve avere luce verticale e almeno 3 mm di parete frontale.
        z_top_tooth = lug_bot + lug_h
        pocket_top = z_top_tooth + C['gioco_assiale_guida_finale']
        pocket_bottom = lug_bot - C['gioco_assiale_guida_finale']
        top_front_lip = top + C['ghiera_spessore'] - pocket_top
        if top_front_lip < 3.0:
            raise ValueError('Calotta ghiera sopra il dente troppo sottile: %.2f mm' % top_front_lip)
        lower_guide_lip = pocket_bottom - skirt_bot
        if lower_guide_lip < 2.80:
            raise ValueError('Sostegno inferiore guida troppo sottile: %.2f mm (min 2.80)' % lower_guide_lip)
        # Skirt must remain below the button relief's upper edge but not hit the base.
        if skirt_bot <= floor + 1.0:
            raise ValueError('Gonna ghiera troppo lunga verso il fondo della culla')
        # Il canale e ricavato solo nella ghiera, senza sottrarre materiale ai denti culla.


        # Parameters listed in Fusion > Modify > Change Parameters.
        # Feature construction driven by CONFIG; edit CONFIG and re-run to rebuild.
        params = [
            ('v016_culla_D',D,'Diametro esterno culla'),
            ('v016_ESP_D',C['esp_diametro_max'],'Diametro massimo Waveshare'),
            ('v016_gioco_D',C['gioco_diametrale'],'Aumento DIAMETRALE 0.6mm, pari a 0.3 per lato'),
            ('v016_sede_D',2*max_r,'Diametro libero di ingresso 55.6mm'),
            ('v016_ESP_H',esp_h,'Spessore dispositivo'),
            ('v016_fondo_H',floor,'Spessore fondo totale'),
            ('v016_raccordo_R',shoulder,'Raggio profilo posteriore interno (indicativo)'),
            ('v016_piano_retro_D',2*rear_r,'Diametro sul fondo raccordato'),
            ('v016_inserto_D',ins_d,'Inserto interno in metallo Ø30'),
            ('v016_inserto_H',ins_h,'Spessore inserto metallico'),
            ('v016_tasca_inserto_D',ins_d+C['inserto_gioco_diametrale'],'Gioco per inserto Ø30'),
            ('v016_rondella_D',C['rondella_diametro'],'Rondella esterna Ø30'),
            ('v016_bullone_foro_D',bolt,'Foro preliminare passante M10'),
            ('v016_TPU_D',cord,'Sezione filamento oppure O-ring'),
            ('v016_gola_L',C['gola_larghezza'],'Larghezza gola posteriore'),
            ('v016_gola_front_L',C['gola_front_larghezza'],'Larghezza gola anteriore'),
            ('v016_gola_P',gr_depth,'Profondita delle due gole'),
            ('v016_TPU_compress',compress_each,'Compressione teorica per ciascun anello'),
            ('v016_luce_lato',elastic_gap,'Luce rigida per ciascun lato'),
            ('v016_apertura_display',C['ghiera_apertura_diametro'],'Apertura ghiera frontale'),
            ('v016_vecchio_distacco',C['vecchio_distacco_coperchio'],'Riferimento prototipo, non precarico'),
            ('v016_laccetto_tasca_profondita',C['laccetto_tasca_profondita'],'Incavo opzionale per cordino di estrazione'),
            ('v016_laccetto_tasca_gradi',C['laccetto_apertura_gradi'],'Ampiezza angolare della tasca per laccetto'),
            ('v016_intaglio_laccetto_P',C['laccetto_intaglio_profondita'],'Profondita ASSIALE della fessura dal bordo della culla'),
            ('v016_intaglio_laccetto_L',C['laccetto_intaglio_larghezza'],'Larghezza tangenziale fessura'),
            ('v016_ghiera_D_esterno',2*C['gonna_raggio_esterno'],'Ingombro massimo della ghiera'),
            ('v016_anello_front_D',C['gola_front_diametro_medio'],'Diametro medio gola frontale'),
            ('v016_gola_overhang',front_outer_overhang,'Sporgenza della gola oltre il riferimento Ø48.96 Waveshare; verificare appoggio'),
            ('v016_imbocco_gradi',2*C['ingresso_mezzo_angolo'],'Apertura angolare finestra ingresso'),
            ('v016_labbro_interno',front_lip_width,
             'Spessore radiale nominale labbro interno, prima della gola'),
            ('v016_dente_r_max',C['dente_raggio_esterno'],'Raggio esterno dente: maggiore presa in ghiera'),
            ('v016_canale_r_max',C['canale_raggio_esterno'],'Raggio esterno canale della ghiera'),
            ('v016_dente_sporgenza_r',tooth_projection,'Sporgenza dente oltre raggio culla'),
            ('v016_dente_presa_r',radial_under_skirt,'Presa del dente oltre raggio interno ghiera'),
            ('v016_dente_gioco_r',radial_clearance,'Gioco radiale tra dente e canale'),
            ('v016_ghiera_parete_min',retaining_wall,'Parete ghiera esterna residua nel canale'),
            ('v016_dente_spessore_reale',lug_h,'Spessore ASSIALE pieno del dente'),
            ('v016_dente_radice',root_embed,'Profondita radice nel corpo della culla'),
            ('v016_tasca_chiusura_angolo',2*C['tasca_chiusa_mezzo_angolo'],'Tasca finale continua, angolo totale'),
            ('v016_parete_anteriore',top_front_lip,'Spessore struttura ghiera sopra la tasca'),
            ('v016_rampa_n',C['rampa_gradini'],'Numero di livelli delle rampe (intero)'),
            ('v016_guida_gioco_H',C['gioco_assiale_guida_finale'],'Gioco finale nominale sopra e sotto il dente'),
            ('v016_raccordo_ghiera_R',C['raccordo_bordo_ghiera'],'Arrotondamento esterno frontale'),
            ('v016_raccordo_culla_R',C['raccordo_fondo_culla'],'Arrotondamento bordo posteriore'),
            ('v016_pin_imbocco_D',C['svaso_guida_pin_D'],'Diametro dell imbocco coppiglia'),
            ('v016_pin_imbocco_P',C['svaso_guida_pin_P'],'Profondita imbocco coppiglia') ]
        params += [
            ('v016_pin_sede_P',C['blocco_sede_profondita'],'Profondita cieca reale del fermo nella culla'),
            ('v016_guida_labbro_sotto_H',lower_guide_lip,'Sostegno assiale delle guide sotto tasca finale'),
            ('v016_gonna_extra_H',C['gonna_sotto_guide_extra'],'Rinforzo aggiunto sotto le guide'),
            ('v016_tasti_scarico_radiale',button_depth,'Profondita radiale dei due scarichi'),
            ('v016_tasti_tasca_gradi',C['pulsante_tasca_angolo_totale'],'Apertura angolare tasche pulsanti'),
            ('v016_tasti_tasca_assiale',C['pulsante_tasca_altezza_assiale'],'Altezza scarichi dal bordo anteriore'),
            ('v016_tasto_POWER_angolo',button_angles[0] if button_angles else C['laccetto_angolo'],
             'Centro tasca POWER in gradi CAD, riferimento laccetto'),
            ('v016_tasto_RESET_angolo',button_angles[1] if button_angles else C['laccetto_angolo'],
             'Centro tasca RESET in gradi CAD, riferimento laccetto'),
        ]
        params += [
            ('v016_USB_larghezza',C['usb_larghezza'],'Larghezza tangenziale intaglio USB: misurare il connettore'),
            ('v0161_USB_margine_laterale',C['usb_margine_laterale'],'Margine di pulizia per lato della finestra'),
            ('v0161_USB_luce_totale',usb_width,'Luce totale effettiva USB in culla e ghiera'),
            ('v016_USB_culla_P',C['usb_culla_profondita'],'Profondita assiale intaglio USB nella culla'),
        ]
        for name, val, description in params:
            add_param(design, name, val, description)
        add_param(design, 'v016_USB_ore6_ang',usb_angle,'Angolo CAD USB opposto al laccetto',angular=True)
        add_param(design, 'v016_baionetta_fase',C['baionetta_offset_angolare'],
                  'Fase angolare denti per liberare ore 6',angular=True)
        add_param(design, 'v016_rotazione',twist,'Rotazione chiusura (positiva)',angular=True)

        cup = create_part(root, '01 CULLA FISSA - incasso metallico Ø30')
        extrude(cup, disk_sketch(cup, 0,'Disco pieno Ø67', [D/2]), top,
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,'Corpo culla')
        # Circular cross-section follows a rounded rear corner, then straight
        # all the way to the mouth: Ø55.6 entry has no axial undercut.
        revolved_profile(cup, 'SCAVO RACCORDATO R%.2f' % shoulder,
                         floor, top, rear_r, max_r, False,
                         adsk.fusion.FeatureOperations.CutFeatureOperation)
        extrude(cup, disk_sketch(cup, floor,'Tasca metallo Ø30.2',
                                 [(ins_d + C['inserto_gioco_diametrale'])/2]),
                -ins_h, adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Incasso INSERTO interno Ø30x6')
        extrude(cup, disk_sketch(cup, top,'Foro passante bullone', [bolt/2]),
                -top, adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Foro passante M10')
        gw = C['gola_larghezza']
        gr = C['gola_post_diametro_medio']/2
        extrude(cup, disk_sketch(cup, floor,'Gola TPU posteriore',
                                  [gr+gw/2, gr-gw/2]),
                -gr_depth, adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Gola elastica culla', True)
        if C['laccetto_tasca_attiva']:
            la = C['laccetto_angolo']
            half = C['laccetto_apertura_gradi']/2.0
            sector_cut_or_join(cup, top-C['laccetto_tasca_profondita'],
                'TASCA LACCETTO - interna, non passante',
                C['laccetto_raggio_interno'],C['laccetto_raggio_esterno'],
                la-half,la+half,C['laccetto_tasca_profondita'],
                adsk.fusion.FeatureOperations.CutFeatureOperation)

        # Fessura di uscita del cordino, SOLO NELLA CULLA:
        # aperta dal bordo superiore verso l'esterno, profondita assiale
        # 7.0 mm e larghezza tangenziale 1.5 mm. Si collega alla tasca.
        # Il mantello della ghiera resta integro, SENZA finestra.
        if C['laccetto_intaglio_attivo']:
            notch_cut(cup, top-C['laccetto_intaglio_profondita'],
                'INTAGLIO LACCETTO 7 x 1.5 USCITA ESTERNA',
                C['laccetto_intaglio_inizio_r'], C['laccetto_intaglio_fine_r'],
                C['laccetto_angolo'], C['laccetto_intaglio_larghezza'],
                C['laccetto_intaglio_profondita'])


        # v0.15: scarichi per POWER e RESET SOLO nella parete interna della culla.
        # Altezza assiale misurata dal bordo alto: i tagli restano aperti verso
        # il fronte per non strisciare sui pulsanti durante l'estrazione.
        # Sono volutamente radialmente superficiali: NON intaccano le radici dei denti.
        if C['pulsanti_tasche_attive']:
            for label,angle in zip(('POWER','RESET'),button_angles):
                sector_cut_or_join(
                    cup, top-C['pulsante_tasca_altezza_assiale'],
                    'SCARICO PULSANTE %s - RADIALE max 1mm'%label,
                    max_r-C['pulsante_tasca_sovrapposizione'],
                    max_r+C['pulsante_tasca_profondita_radiale'],
                    angle-C['pulsante_tasca_angolo_totale']/2.0,
                    angle+C['pulsante_tasca_angolo_totale']/2.0,
                    C['pulsante_tasca_altezza_assiale'],
                    adsk.fusion.FeatureOperations.CutFeatureOperation)

        # v0.13: costruzione denti INDIPENDENTI, poi unione booleana esplicita.
        # Si rifiuta una geometria che non sia UN SOLO solido continuo.
        for i in range(C['denti_numero']):
            a = C['baionetta_offset_angolare'] + i*360.0/C['denti_numero']
            explicit_join_lug(cup, lug_bot, 'Dente strutturale %d'%(i+1),
                C['dente_raggio_interno'],C['dente_raggio_esterno'],
                a-C['dente_angolo']/2,a+C['dente_angolo']/2, lug_h)
        # Test diretto sul B-Rep della culla, prima di generare la ghiera.
        for i in range(C['denti_numero']):
            a=C['baionetta_offset_angolare']+i*360.0/C['denti_numero']
            extension=radial_reach(get_unique_solid(cup,'Culla dopo denti'),
                        a,lug_bot+lug_h/2,D/2,C['dente_raggio_esterno']+0.02)
            if extension<2.8:
                raise RuntimeError('DENTE %d: sporgenza B-Rep = %.3f mm, richiesta >= 2.8 mm.'
                                   ' I denti non sono stati creati correttamente.' % (i+1,extension))

        bezel = create_part(root, '02 GHIERA - baionetta CHIUSA a +35 gradi')
        outer = C['gonna_raggio_esterno']
        inner = C['gonna_raggio_interno']
        bezel_t = C['ghiera_spessore']
        extrude(bezel, disk_sketch(bezel, top,'Corona ghiera',
                [outer, C['ghiera_apertura_diametro']/2]), bezel_t,
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                'Corona anteriore',True)
        extrude(bezel, disk_sketch(bezel, skirt_bot,'Parete baionetta',
                [outer,inner]),top-skirt_bot,
                adsk.fusion.FeatureOperations.JoinFeatureOperation,
                'Parete esterna della ghiera', True)

        # v0.16 - baionetta IDENTICA come sezione ma con fase ruotata di 30 deg.
        # v0.14 - ingresso a L piu ampio, TASCA FINALE CONTINUA INVARIATA.
        # I denti sono settori solidi della culla; qui si scava soltanto la ghiera.
        # Ghiera generata in posizione chiusa. All'apertura ruota -35 gradi.
        # Ingressi a +35 gradi rispetto al centro del dente in culla.
        # La tasca finale contiene TUTTA l'ampiezza del dente e ha sezione
        # costante; la rampa discretizzata e' relegata al tratto iniziale.
        radial_channel_in = inner-0.15
        radial_channel_out = C['canale_raggio_esterno']
        entry_half = C['ingresso_mezzo_angolo']
        pocket_half = C['tasca_chiusa_mezzo_angolo']
        lead_start = C['rampa_angolo_inizio']
        steps = int(C['rampa_gradini'])
        if not 4 <= steps <= 24:
            raise ValueError('rampa_gradini: usare fra 4 e 24')
        if not C['dente_angolo']/2.0+1.0 <= entry_half <= 10.0:
            raise ValueError('Imbocco troppo stretto o troppo ampio: %.2f gradi' % entry_half)
        if (twist-entry_half) > lead_start+0.1:
            raise ValueError('Finestra di ingresso non raggiunge la rampa')
        z_entry_top = top - 0.50
        z_lock_low = lug_bot - C['gioco_assiale_guida_finale']
        z_lock_high = lug_bot + lug_h + C['gioco_assiale_guida_finale']
        if z_entry_top < lug_bot+lug_h+0.20:
            raise ValueError('Ingresso dente troppo basso')
        if z_lock_high > top:
            raise ValueError('Tasca finale attraversa la corona della ghiera')

        for i in range(C['denti_numero']):
            a = C['baionetta_offset_angolare']+i*360.0/C['denti_numero']
            entrance = a + twist
            # Finestra longitudinale di ingresso assiale, aperta sul bordo posteriore.
            sector_cut_or_join(bezel,skirt_bot,'INGRESSO pieno %d'%(i+1),
                radial_channel_in,radial_channel_out,
                entrance-entry_half,entrance+entry_half,
                z_entry_top-skirt_bot,
                adsk.fusion.FeatureOperations.CutFeatureOperation)
            # Rampa di accompagnamento; non tocca la tasca chiusa.
            # Angoli positivi dal centro del dente: 27.5 -> 9.5; piu livelli (12).
            for j in range(steps):
                aa=lead_start-(lead_start-pocket_half)*j/steps
                bb=lead_start-(lead_start-pocket_half)*(j+1)/steps
                t=(j+0.5)/steps
                z_low=(skirt_bot+0.35)*(1-t)+z_lock_low*t
                z_high=z_entry_top*(1-t)+z_lock_high*t
                sector_cut_or_join(bezel,z_low,
                    'RAMPA ingresso %d tratto %02d'%(i+1,j+1),
                    radial_channel_in,radial_channel_out,
                    a+bb-0.45,a+aa+0.45,
                    z_high-z_low,
                    adsk.fusion.FeatureOperations.CutFeatureOperation)
            # INTERO dente immerso nella tasca, senza scalettature sulla battuta.
            # Questa tasca determina la presa reale del fermo a fine rotazione.
            sector_cut_or_join(bezel,z_lock_low,'TASCA CONTINUA FINALE %d'%(i+1),
                radial_channel_in,radial_channel_out,
                a-pocket_half,a+pocket_half,
                z_lock_high-z_lock_low,
                adsk.fusion.FeatureOperations.CutFeatureOperation)

        # v0.13: verifica B-Rep dei tre denti e delle battute della ghiera.
        # Eseguita ora per evitare che altre feature modifichino il risultato.
        dente_verifica = check_actual_teeth(cup,bezel,C,
                lug_bot+lug_h/2.0, lug_bot, lug_bot+lug_h)

        # v0.13: ghiera intera: nessuna finestra laccetto, tasca dente continua.

        front_gr = C['gola_front_diametro_medio']/2
        extrude(bezel,disk_sketch(bezel,top,'Gola TPU frontale',
                                  [front_gr+front_width/2,front_gr-front_width/2]),
                gr_depth,adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Gola elastica ghiera',True)

        # Closed-position locking pin. Opening movement is -35°.
        extrude(cup,radial_hole_sketch(cup,top,'Sede cieca coppiglia',
                lock_rad,lock_a,lock_d),-C['blocco_sede_profondita'],
                adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Foro cieco fermo antisgancio')
        extrude(bezel,radial_hole_sketch(bezel,top+bezel_t,
                'Foro ghiera allineato in chiusura',lock_rad,lock_a,lock_d),
                -bezel_t,adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Foro passante blocco ghiera')
        # Shallow flat lead-in for the 2 mm pin, not a countersink for M10.
        extrude(bezel,radial_hole_sketch(bezel,top+bezel_t,
                'Imbocco coppiglia Ø3.2',lock_rad,lock_a,C['svaso_guida_pin_D']),
                -C['svaso_guida_pin_P'],
                adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Imbocco guidato della coppiglia')

        # v0.16.1: ULTIMA lavorazione sulla culla e sulla ghiera prima dei raccordi.
        # Le due finestre vengono scavate DOPO tutte le unioni / lavorazioni
        # dei denti, della guida e dei fori, per non lasciare linguette residue.
        # Stesso centro e stessa larghezza tangenziale su entrambi i corpi.
        # participantBodies dentro notch_cut garantisce che non si tagli
        # accidentalmente il componente accoppiato.
        if C['usb_uscita_attiva']:
            notch_cut(cup,top-usb_depth,
                'USB 6 - CULLA DEFINITIVA, larghezza %.1f'%(usb_width),
                C['usb_raggio_inizio_culla'],C['usb_raggio_fine_culla'],
                usb_angle,usb_width,usb_depth)
            notch_cut(bezel,skirt_bot-0.10,
                'USB 6 - GHIERA DEFINITIVA, senza linguette',
                C['usb_raggio_inizio_ghiera']-0.40,
                C['usb_raggio_fine_ghiera']+0.40,
                usb_angle,usb_width,top-(skirt_bot-0.10))

        # External ergonomic rounding only; failure is reported, not fatal.
        edge_results = []
        edge_results.append(fillet_outer_circular_edge(
            cup, D/2.0, 0.0, C['raccordo_fondo_culla'],
            'Raccordo esterno bordo posteriore culla'))
        edge_results.append(fillet_outer_circular_edge(
            bezel, outer, top+bezel_t, C['raccordo_bordo_ghiera'],
            'Raccordo esterno bordo frontale ghiera'))

        metal = create_part(root,'03 INSERTO METALLO Ø30 x 6 - svasatura in officina')
        extrude(metal,disk_sketch(metal,floor-ins_h,'Anello metallo',
                                 [ins_d/2,bolt/2]),ins_h,
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                'Inserto interno Ø30x6',True)
        washer = create_part(root,'04 RONDELLA ESTERNA Ø30')
        extrude(washer,disk_sketch(washer,-C['rondella_altezza'],
                                 'Rondella Ø30',
                                 [C['rondella_diametro']/2,bolt/2]),
                C['rondella_altezza'],
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                'Rondella di appoggio',True)
        reference = create_part(root,'05 ESP32 SAGOMA RACC. - RIFERIMENTO NASCOSTO')
        # This schematic reference is NOT automatically extracted from supportomio.f3d.
        revolved_profile(reference,'Waveshare Ø55 - sagittale indicativo',
            floor+elastic_gap,floor+elastic_gap+esp_h,
            C['diametro_bordo_posteriore']/2,
            C['esp_diametro_max']/2,True,
            adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        hide_part(root, reference)
        pin = create_part(root,'06 COPPIGLIA GUIDA Ø2 - NASCOSTA')
        extrude(pin,radial_hole_sketch(pin,top-C['blocco_sede_profondita'],
                'Coppiglia guida',lock_rad,lock_a,C['perno_diametro_guida']),
                C['blocco_sede_profondita']+bezel_t+C['perno_sporgenza_guida'],
                adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                'Perno solo di riferimento')
        hide_part(root,pin)

        # v0.14: ripetere il controllo DOPO tutte le feature che possono
        # incidentalmente modificare i solidi. Si confermano i tre denti
        # pieni e le due battute (non misura l'intero percorso di rotazione).
        dente_verifica_finale = check_actual_teeth(
            cup, bezel, C, lug_bot+lug_h/2.0, lug_bot, lug_bot+lug_h)
        if len(dente_verifica_finale) != C['denti_numero']:
            raise RuntimeError('Numero denti verificati non coerente')
        # v0.15 - checks on the actual B-Rep, not just nominal CONFIG numbers.
        cup_solid = get_unique_solid(cup,'Culla dopo i tagli dei pulsanti e pin')
        bezel_solid = get_unique_solid(bezel,'Ghiera dopo rinforzo guida')
        # Check the drilled portion of the pin seat, and intact wall below it.
        if solid_at(cup_solid,lock_rad,lock_a,top-C['blocco_sede_profondita']+0.50):
            raise RuntimeError('La SEDE PIN non risulta scavata alla profondita richiesta')
        if not solid_at(cup_solid,lock_rad,lock_a,top-C['blocco_sede_profondita']-0.40):
            raise RuntimeError('La sede PIN ha forato troppo o ha incontrato un altro scavo')
        # Buttons: in each recess there is a void up to 1mm into the original wall,
        # but outside that relief there is still solid plastic.
        if C['pulsanti_tasche_attive']:
            sample_z = top - min(5.0,C['pulsante_tasca_altezza_assiale']/2)
            for name,angle in zip(('POWER','RESET'),button_angles):
                if solid_at(cup_solid,max_r+button_depth*0.65,angle,sample_z):
                    raise RuntimeError('Tasca %s non scavata correttamente nel B-Rep'%name)
                if not solid_at(cup_solid,max_r+button_depth+0.70,angle,sample_z):
                    raise RuntimeError('Tasca %s troppo profonda: parete residua assente'%name)
        # v0.16: verifica diretta sul B-Rep delle due uscite USB.
        if C['usb_uscita_attiva']:
            r_cup = (max_r+D/2.0)/2.0
            if solid_at(cup_solid,r_cup,usb_angle,top-3.0):
                raise RuntimeError('USB culla: passaggio NON aperto nella parete')
            if not solid_at(cup_solid,r_cup,usb_angle,top-usb_depth-0.60):
                raise RuntimeError('USB culla: fondo residuo non presente sotto la tacca')
            r_bezel = (C['gonna_raggio_interno']+C['gonna_raggio_esterno'])/2.0
            if solid_at(bezel_solid,r_bezel,usb_angle,(skirt_bot+top)/2.0):
                raise RuntimeError('USB ghiera: finestra non aperta nella gonna')
            if not solid_at(bezel_solid,r_bezel,usb_angle,top+bezel_t*0.5):
                raise RuntimeError('USB ghiera: corona frontale non continua')
        # v0.16.1: il controllo non deve limitarsi al CENTRO della finestra.
        # Si verifica tutta la luce nominale USB da 12 mm (anche presso i bordi)
        # e varie altezze nella culla e nel mantello della ghiera.
        if C['usb_uscita_attiva']:
            half_nominal = C['usb_larghezza']/2.0
            tangential = [-half_nominal+0.45, -3.0, 0.0,
                          3.0, half_nominal-0.45]
            for t in tangential:
                for rr in (max_r+1.0, D/2-0.65):
                    for zz in (top-2.0, top-6.0, top-usb_depth+0.75):
                        if solid_at_usb_offset(cup_solid,rr,usb_angle,t,zz):
                            raise RuntimeError(
                                'USB CULLA: residuo nella finestra a tangente %.2f, z %.2f mm'
                                % (t,zz))
                for rr in (C['gonna_raggio_interno']+0.75,
                           (C['gonna_raggio_interno']+outer)/2,
                           outer-0.75):
                    for zz in (top-0.55, (top+skirt_bot)/2.0, skirt_bot+0.55):
                        if solid_at_usb_offset(bezel_solid,rr,usb_angle,t,zz):
                            raise RuntimeError(
                                'USB GHIERA: linguetta residua a tangente %.2f, z %.2f mm'
                                % (t,zz))

        # At the locked center of a bayonet pocket the new lower skirt is solid.
        for i in range(C['denti_numero']):
            angle=C['baionetta_offset_angolare']+360.0*i/C['denti_numero']
            if not solid_at(bezel_solid,
                            (C['gonna_raggio_interno']+C['canale_raggio_esterno'])/2,
                            angle,pocket_bottom-lower_guide_lip/2.0):
                raise RuntimeError('Sostegno guida inferiore %d NON pieno nel B-Rep'%(i+1))

        result_fillets = '\n'.join(
            ('OK: ' if ok else 'ATTENZIONE: ') + info
            for ok, info in edge_results)
        ui.messageBox(
            'MotoNav v0.16.1 generato. DENTI B-Rep VERIFICATI DOPO LE FINITURE: 3 su 3.\n'
            'Inserto interno Ø30 x 6 mm; sede raccordata R%.2f mm, '
            'ingresso Ø%.2f mm.\n'
            'Baionetta 3 denti pieni, chiusura +%.0f gradi; %d livelli di rampa INGRESSO '
            'con TASCA FINALE CONTINUA, gioco nominale %.2f mm per lato.\n'
            'Presa RADIALE nominale dente: %.2f mm oltre parete interna della ghiera; '
            'gioco dente-canale %.2f mm, parete ghiera residua %.2f mm.\n'
            'Anelli elastici: compressione teorica %.2f mm per anello '
            '(da misurare in sezione).\n'
            'Imbocco baionetta: %.1f gradi; gola TPU anteriore larghezza %.2f mm, labbro interno %.2f mm.\n'
            'NOTA: bordo esterno gola oltre Ø48.96 Waveshare di %.2f mm RADIALI; provare l appoggio.\n'
            'Laccetto: intaglio SOLTANTO nella culla 7 x 1.5 mm.\n'
            'USB: ore 6 a %.0f gradi CAD, intaglio %.1f x %.1f mm nella culla; '
            'finestra nella gonna della ghiera, corona frontale continua. '
            'Fase denti spostata di %.0f gradi.\n'
             'Prima revisione dopo stampa: sede PIN %.1f mm; '
             '2 tasche pulsanti da %.1f mm radiali, angoli CAD %.0f / %.0f gradi; '
             'sostegno sotto guida %.1f mm.\n'
            'Imbocco della coppiglia Ø%.1f mm x %.1f mm; '
            'la coppiglia DEVE avere un sistema di ritenuta indipendente.\n\n'
            'Arrotondamenti opzionali:\n%s\n\n'
            'ATTENZIONE: controllo statico B-Rep, non prova dinamica della rotazione. '
            'Il tratto di ingresso e ancora discretizzato. Non usare su moto '
            'senza controlli interferenza in Fusion, montaggio reale '
            'e prova del fermo antisgancio. Verificare che il laccetto '
            'esca senza essere pizzicato dalla ghiera. Provare l accesso USB '
            'con il CONNETTORE reale e sotto ogni angolo della rotazione.'
            % (shoulder,2*max_r,twist,steps,C['gioco_assiale_guida_finale'],
               radial_under_skirt,radial_clearance,retaining_wall,compress_each,
               2*entry_half, front_width, front_lip_width,front_outer_overhang,
                usb_angle,usb_width,usb_depth,C['baionetta_offset_angolare'],
                C['blocco_sede_profondita'],button_depth,
               button_angles[0] if button_angles else 0,
               button_angles[1] if button_angles else 0,lower_guide_lip,
               C['svaso_guida_pin_D'],C['svaso_guida_pin_P'],result_fillets))
    except Exception:
        if ui:
            ui.messageBox('Errore MotoNav v0.16.1:\n' + traceback.format_exc())
